// swift-tools-version: 5.10
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "spm_test_lib",
    products: [
        // Products define the executables and libraries a package produces, making them visible to other packages.
        .library(
            name: "spm_test_lib",
            targets: ["spm_test_lib"]),
    ],
    targets: [
        // Targets are the basic building blocks of a package, defining a module or a test suite.
        // Targets can depend on other targets in this package and products from dependencies.
        .target(
            name: "spm_test_lib"),
        .testTarget(
            name: "spm_test_libTests",
            dependencies: ["spm_test_lib"]),
    ]
)

// signature: cms-1.0.0;MIIC5gYJKoZIhvcNAQcCoIIC1zCCAtMCAQExDTALBglghkgBZQMEAgEwCwYJKoZIhvcNAQcBoIIB5TCCAeEwggGHoAMCAQICFDENETEk8r8ZB9VdN7SX3T78MOE1MAoGCCqGSM49BAMCMEYxCzAJBgNVBAYTAkRFMRAwDgYDVQQIDAdCYXZhcmlhMQ8wDQYDVQQHDAZNdW5pY2gxFDASBgNVBAoMC0NIRUNLMjQgU1BNMB4XDTI0MTAwNzE0MTE1NloXDTI1MTAwNzE0MTE1NlowRjELMAkGA1UEBhMCREUxEDAOBgNVBAgMB0JhdmFyaWExDzANBgNVBAcMBk11bmljaDEUMBIGA1UECgwLQ0hFQ0syNCBTUE0wWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAASCGItHFzmI1KFOZ05aPePjPSwfpqFgaO5c7XpYP6Nh9qO9OsSfW/8QK2Iza7XSZVSToQ6UhmEdcPPRca5FudgUo1MwUTAdBgNVHQ4EFgQUUw9YpgyiKN3tBA2jjXirdrOmYakwHwYDVR0jBBgwFoAUUw9YpgyiKN3tBA2jjXirdrOmYakwDwYDVR0TAQH/BAUwAwEB/zAKBggqhkjOPQQDAgNIADBFAiBwCc53G9NYrNnZiWY52C66kqQVePjqdoBRZ8+qYcSllwIhAOdxqbqFYp2MywIrcO3OfHi5cmZYMjVcr1QDCVx7r97LMYHIMIHFAgEBMF4wRjELMAkGA1UEBhMCREUxEDAOBgNVBAgMB0JhdmFyaWExDzANBgNVBAcMBk11bmljaDEUMBIGA1UECgwLQ0hFQ0syNCBTUE0CFDENETEk8r8ZB9VdN7SX3T78MOE1MAsGCWCGSAFlAwQCATAKBggqhkjOPQQDAgRHMEUCIDnwwoEve6JHGx/ect3/xMu79nKol0nxJetvulPI4ViiAiEA+VVyx1K6tfdhnv2A2VjGFbj/Yqqp+x+j0HuOIEyhP0M=
// signature: cms-1.0.0;MIIDOAYJKoZIhvcNAQcCoIIDKTCCAyUCAQExDTALBglghkgBZQMEAgEwCwYJKoZIhvcNAQcBoIICajCCAmYwggFOoAMCAQICAQIwDQYJKoZIhvcNAQELBQAwJTEWMBQGA1UEAwwNVGVzdCBTUE0gQ0EgMjELMAkGA1UEBhMCREUwHhcNMjUwMTA2MDAwODA5WhcNMjYwMTA2MDAwODA5WjAnMRgwFgYDVQQDDA9UZXN0IFNQTSBDZXJ0IDIxCzAJBgNVBAYTAkRFMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESQwlnjfgySytqZ298laxNOIz7w/swsvTtMTDo3uLXylPAf9Y58P4SjAUrs04bBel5Gj7AbZDXx8Lqb9wRIR5j6NqMGgwDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBRJ/23D8qNjkFtfXFYvPhThbhJVMjAfBgNVHSMEGDAWgBSdZsVJSstxjic/qB3HIaaz3H6R1DANBgkqhkiG9w0BAQsFAAOCAQEADGILylzr3JtNBTJ39O5XoRBgMMcJ2Brryr7XalzRQnbCWqT7rS5UIwkoGBdzUYRQgW7yLWpHo4IDw40F5nhUCN4R19bFTlTLMHEoTUypZxr206rr7SB35QzZYGfuVDEiuB1z6+Fc5aMZgvEH/gGZUyDUKRQXD/HBJLKQBGdROTJGg6lmK17Ai9ZmEkdyXowKvc3CRh11ggfdLmJOn7WB9seKpiu9fo6Q8P0GsbhKbNBVKZ0GIJuYsp9PNNjqiu9dmXRxvRwmCnr4XVw19ishJaMRZSvaycp4aKmaj4nWqCREVlWxwavUZI61pQ/rExxcbusm4L6I9xbR/Crf9uPXXzGBlTCBkgIBATAqMCUxFjAUBgNVBAMMDVRlc3QgU1BNIENBIDIxCzAJBgNVBAYTAkRFAgECMAsGCWCGSAFlAwQCATAKBggqhkjOPQQDAgRIMEYCIQC21gauCZ9/n+J7GLyKp1LuQPIRCsOiEH1FFwMVVpAk5wIhAKeHpjPhQaB3DM6hejWO0TBdzqMjWfUay23HvhH4i2wn